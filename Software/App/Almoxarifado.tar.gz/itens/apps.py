from django.apps import AppConfig


class ItensConfig(AppConfig):
    name = 'itens'
