from rest_framework.serializers import ModelSerializer
from registros.models import RequisicaoMateriais

class RequisicaoMateriaisSerializer(ModelSerializer):
    class Meta:
        model = RequisicaoMateriais
        fields = ('id', 'dataRegistro', 'condicao', 'observacoes', 'idRequisitante')
