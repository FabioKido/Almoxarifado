from django.apps import AppConfig


class RegistrosConfig(AppConfig):
    name = 'registros'
