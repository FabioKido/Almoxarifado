from django.apps import AppConfig


class CrudsConfig(AppConfig):
    name = 'cruds'
