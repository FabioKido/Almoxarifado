from django.apps import AppConfig


class MateriaisConfig(AppConfig):
    name = 'materiais'
